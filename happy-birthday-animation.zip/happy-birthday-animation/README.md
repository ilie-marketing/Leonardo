# Happy Birthday Animation

A Pen created on CodePen.io. Original URL: [https://codepen.io/slic84/pen/rbbRva](https://codepen.io/slic84/pen/rbbRva).

Code taken from Codeacademy's hour of code project to animate your name.